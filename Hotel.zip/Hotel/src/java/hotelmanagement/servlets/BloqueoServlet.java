package hotelmanagement.servlets;

import hotelmanagement.utils.Logger;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BloqueoServlet")
public class BloqueoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        Connection conn = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hoteldb", "root", "");
            
            out.println("<!DOCTYPE html>");
            out.println("<html><head>");
            out.println("<meta charset='UTF-8'>");
            out.println("<title>Gestión de Bloqueos</title>");
            out.println("<style>");
            out.println("body { font-family: Arial; background: linear-gradient(135deg, rgba(44, 62, 80, 0.95) 0%, rgba(52, 73, 94, 0.95) 100%), url('https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1920&q=80') center/cover fixed; min-height: 100vh; padding: 20px; }");
            out.println(".container { max-width: 1200px; margin: 0 auto; }");
            out.println(".card { background: rgba(255,255,255,0.98); backdrop-filter: blur(20px); padding: 30px; border-radius: 15px; margin-bottom: 20px; box-shadow: 0 8px 32px rgba(0,0,0,0.15); }");
            out.println("h1 { color: #2c3e50; margin-bottom: 20px; }");
            out.println(".grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 15px; }");
            out.println(".habitacion { background: white; border: 2px solid #e0e0e0; border-radius: 10px; padding: 20px; text-align: center; cursor: pointer; transition: all 0.3s; }");
            out.println(".habitacion:hover { transform: translateY(-5px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }");
            out.println(".habitacion.disponible { border-color: #27ae60; background: #e8f5e9; }");
            out.println(".habitacion.disponible:hover { background: #c8e6c9; }");
            out.println(".habitacion.ocupada { border-color: #f39c12; background: #fff3e0; }");
            out.println(".habitacion.mantenimiento { border-color: #e74c3c; background: #ffebee; }");
            out.println(".habitacion-numero { font-size: 1.8em; font-weight: bold; color: #2c3e50; margin-bottom: 5px; }");
            out.println(".habitacion-estado { font-size: 0.85em; font-weight: 600; text-transform: uppercase; }");
            out.println(".habitacion-tipo { font-size: 0.75em; color: #666; margin-top: 5px; }");
            out.println(".btn { padding: 10px 20px; background: #3498db; color: white; border: none; border-radius: 8px; cursor: pointer; text-decoration: none; margin: 5px; display: inline-block; transition: all 0.3s; }");
            out.println(".btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4); }");
            out.println(".btn-danger { background: #e74c3c; }");
            out.println(".btn-success { background: #27ae60; }");
            out.println(".leyenda { display: flex; gap: 20px; margin: 20px 0; flex-wrap: wrap; }");
            out.println(".leyenda-item { display: flex; align-items: center; gap: 10px; }");
            out.println(".leyenda-color { width: 30px; height: 30px; border-radius: 5px; border: 2px solid #ccc; }");
            out.println(".alert { padding: 15px; background: #d4edda; border: 1px solid #c3e6cb; color: #155724; border-radius: 8px; margin-bottom: 20px; }");
            out.println(".alert-warning { background: #fff3cd; border-color: #ffeaa7; color: #856404; }");
            out.println("table { width: 100%; border-collapse: collapse; margin-top: 20px; }");
            out.println("th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }");
            out.println("th { background: #34495e; color: white; }");
            out.println("</style>");
            out.println("</head><body>");
            out.println("<div class='container'>");
            
            String msg = request.getParameter("msg");
            if ("bloqueada".equals(msg)) {
                out.println("<div class='alert'>✓ Habitación bloqueada exitosamente</div>");
            } else if ("desbloqueada".equals(msg)) {
                out.println("<div class='alert'>✓ Habitación desbloqueada exitosamente</div>");
            }
            
            out.println("<div class='card'>");
            out.println("<h1>🚧 Gestión de Bloqueo de Habitaciones</h1>");
            out.println("<p style='color: #666; margin-bottom: 20px;'>Bloquea habitaciones para mantenimiento, limpieza o reparaciones. Las habitaciones bloqueadas no estarán disponibles para reservas.</p>");
            
            out.println("<div class='leyenda'>");
            out.println("<div class='leyenda-item'><div class='leyenda-color' style='background: #e8f5e9; border-color: #27ae60;'></div><span>Disponible</span></div>");
            out.println("<div class='leyenda-item'><div class='leyenda-color' style='background: #fff3e0; border-color: #f39c12;'></div><span>Ocupada</span></div>");
            out.println("<div class='leyenda-item'><div class='leyenda-color' style='background: #ffebee; border-color: #e74c3c;'></div><span>Mantenimiento</span></div>");
            out.println("</div>");
            
            out.println("<a href='dashboard.jsp' class='btn'>← Volver al Dashboard</a>");
            out.println("<a href='BloqueoServlet?ver=historial' class='btn'>📋 Ver Historial</a>");
            out.println("</div>");
            
            String ver = request.getParameter("ver");
            if ("historial".equals(ver)) {
                mostrarHistorial(out, conn);
            } else {
                mostrarHabitaciones(out, conn);
            }
            
            out.println("</div>");
            out.println("</body></html>");
            
        } catch (Exception e) {
            Logger.error("Error en gestión de bloqueos", e);
            out.println("<h2>Error: " + e.getMessage() + "</h2>");
        } finally {
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }
    
    private void mostrarHabitaciones(PrintWriter out, Connection conn) throws SQLException {
        out.println("<div class='card'>");
        out.println("<h2>🏨 Estado de Habitaciones</h2>");
        
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT * FROM Habitacion ORDER BY numeroHabitacion");
        ResultSet rs = stmt.executeQuery();
        
        out.println("<div class='grid'>");
        
        while (rs.next()) {
            int numero = rs.getInt("numeroHabitacion");
            String estado = rs.getString("estado");
            String tipo = rs.getString("tipo");
            if (tipo == null) tipo = "Estándar";
            
            String claseEstado = "disponible";
            if ("Ocupada".equals(estado)) {
                claseEstado = "ocupada";
            } else if ("Mantenimiento".equals(estado)) {
                claseEstado = "mantenimiento";
            }
            
            out.println("<div class='habitacion " + claseEstado + "'>");
            out.println("<div class='habitacion-numero'>" + numero + "</div>");
            out.println("<div class='habitacion-estado'>" + estado + "</div>");
            out.println("<div class='habitacion-tipo'>" + tipo + "</div>");
            
            if ("Disponible".equals(estado)) {
                out.println("<form action='BloquearHabitacionServlet' method='post' style='margin-top: 10px;'>");
                out.println("<input type='hidden' name='numeroHabitacion' value='" + numero + "'>");
                out.println("<input type='hidden' name='accion' value='bloquear'>");
                out.println("<button type='submit' class='btn btn-danger' style='font-size: 0.85em; padding: 5px 10px;'>🚧 Bloquear</button>");
                out.println("</form>");
            } else if ("Mantenimiento".equals(estado)) {
                out.println("<form action='BloquearHabitacionServlet' method='post' style='margin-top: 10px;'>");
                out.println("<input type='hidden' name='numeroHabitacion' value='" + numero + "'>");
                out.println("<input type='hidden' name='accion' value='desbloquear'>");
                out.println("<button type='submit' class='btn btn-success' style='font-size: 0.85em; padding: 5px 10px;'>✓ Liberar</button>");
                out.println("</form>");
            } else {
                out.println("<p style='font-size: 0.75em; color: #999; margin-top: 10px;'>Debe completar check-out</p>");
            }
            
            out.println("</div>");
        }
        
        out.println("</div>");
        out.println("</div>");
    }
    
    private void mostrarHistorial(PrintWriter out, Connection conn) throws SQLException {
        out.println("<div class='card'>");
        out.println("<h2>📋 Historial de Bloqueos</h2>");
        
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT * FROM HistorialBloqueo ORDER BY fechaBloqueo DESC LIMIT 50");
        ResultSet rs = stmt.executeQuery();
        
        out.println("<table>");
        out.println("<tr><th>Habitación</th><th>Acción</th><th>Motivo</th><th>Fecha</th><th>Usuario</th></tr>");
        
        int count = 0;
        while (rs.next()) {
            count++;
            out.println("<tr>");
            out.println("<td><strong>Hab " + rs.getInt("numeroHabitacion") + "</strong></td>");
            out.println("<td>" + rs.getString("accion") + "</td>");
            out.println("<td>" + rs.getString("motivo") + "</td>");
            out.println("<td>" + rs.getTimestamp("fechaBloqueo") + "</td>");
            out.println("<td>" + (rs.getString("usuario") != null ? rs.getString("usuario") : "Sistema") + "</td>");
            out.println("</tr>");
        }
        
        if (count == 0) {
            out.println("<tr><td colspan='5' style='text-align: center; padding: 20px; color: #999;'>No hay registros de bloqueos</td></tr>");
        }
        
        out.println("</table>");
        out.println("</div>");
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}