package hotelmanagement.servlets;

import hotelmanagement.utils.Logger;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DetalleReservaServlet")
public class DetalleReservaServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String idStr = request.getParameter("id");
        String msg = request.getParameter("msg");
        
        if (idStr == null) {
            response.sendRedirect("dashboard.jsp");
            return;
        }
        
        int numeroReserva = Integer.parseInt(idStr);
        Connection conn = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hoteldb", "root", "");
            
            out.println("<!DOCTYPE html>");
            out.println("<html><head>");
            out.println("<title>Detalle de Reserva #" + numeroReserva + "</title>");
            out.println("<style>");
            out.println("body { font-family: Arial; background: linear-gradient(135deg, rgba(44, 62, 80, 0.95) 0%, rgba(52, 73, 94, 0.95) 100%), url('https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1920&q=80') center/cover fixed; min-height: 100vh; padding: 20px; }");
            out.println(".container { max-width: 900px; margin: 0 auto; }");
            out.println(".card { background: rgba(255,255,255,0.98); backdrop-filter: blur(20px); padding: 30px; border-radius: 15px; margin-bottom: 20px; box-shadow: 0 8px 32px rgba(0,0,0,0.15); }");
            out.println("h1 { color: #2c3e50; margin-bottom: 10px; }");
            out.println(".info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin: 20px 0; }");
            out.println(".info-item { padding: 15px; background: #f8f9fa; border-radius: 8px; }");
            out.println(".info-label { font-weight: bold; color: #666; font-size: 0.9em; margin-bottom: 5px; }");
            out.println(".info-value { color: #2c3e50; font-size: 1.1em; }");
            out.println(".btn { padding: 10px 20px; background: #3498db; color: white; border: none; border-radius: 8px; cursor: pointer; text-decoration: none; margin: 5px; display: inline-block; transition: all 0.3s; }");
            out.println(".btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4); }");
            out.println(".btn-success { background: #27ae60; }");
            out.println(".btn-danger { background: #e74c3c; }");
            out.println(".btn-warning { background: #f39c12; }");
            out.println(".estado { padding: 8px 15px; border-radius: 8px; font-weight: bold; display: inline-block; }");
            out.println(".estado-pendiente { background: #f39c12; color: white; }");
            out.println(".estado-activa { background: #27ae60; color: white; }");
            out.println(".estado-completada { background: #95a5a6; color: white; }");
            out.println(".estado-cancelada { background: #e74c3c; color: white; }");
            out.println("table { width: 100%; border-collapse: collapse; margin-top: 15px; }");
            out.println("th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }");
            out.println("th { background: #34495e; color: white; }");
            out.println(".total { font-size: 1.3em; font-weight: bold; color: #27ae60; text-align: right; padding: 15px; background: #e8f5e9; border-radius: 8px; margin-top: 15px; }");
            out.println(".alert { padding: 15px; background: #d4edda; border: 1px solid #c3e6cb; color: #155724; border-radius: 8px; margin-bottom: 20px; }");
            out.println("</style>");
            out.println("</head><body>");
            out.println("<div class='container'>");
            
            // Mensaje de éxito
            if ("checkin".equals(msg)) {
                out.println("<div class='alert'>✓ Check-in realizado exitosamente</div>");
            } else if ("checkout".equals(msg)) {
                out.println("<div class='alert'>✓ Check-out realizado exitosamente</div>");
            } else if ("cargo".equals(msg)) {
                out.println("<div class='alert'>✓ Cargo agregado exitosamente</div>");
            } else if ("pago".equals(msg)) {
                out.println("<div class='alert'>✓ Pago registrado exitosamente</div>");
            }
            
            // Obtener datos de reserva
            PreparedStatement stmt = conn.prepareStatement(
                "SELECT * FROM Reserva WHERE numeroReserva = ?");
            stmt.setInt(1, numeroReserva);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                String nombre = rs.getString("nombreOcupante");
                String telefono = rs.getString("telefono");
                String email = rs.getString("email");
                int habitacion = rs.getInt("numeroHabitacion");
                Date entrada = rs.getDate("fechaEntrada");
                Date salida = rs.getDate("fechaSalida");
                String estado = rs.getString("estadoReserva");
                if (estado == null) estado = "Pendiente";
                double precioBase = rs.getDouble("precioTotal");
                
                String estadoClass = "estado-" + estado.toLowerCase();
                
                out.println("<div class='card'>");
                out.println("<h1>🏨 Reserva #" + numeroReserva + "</h1>");
                out.println("<span class='estado " + estadoClass + "'>" + estado + "</span>");
                
                out.println("<div class='info-grid'>");
                out.println("<div class='info-item'><div class='info-label'>Cliente</div><div class='info-value'>" + nombre + "</div></div>");
                out.println("<div class='info-item'><div class='info-label'>Habitación</div><div class='info-value'>#" + habitacion + "</div></div>");
                out.println("<div class='info-item'><div class='info-label'>Teléfono</div><div class='info-value'>" + (telefono != null ? telefono : "N/A") + "</div></div>");
                out.println("<div class='info-item'><div class='info-label'>Email</div><div class='info-value'>" + (email != null ? email : "N/A") + "</div></div>");
                out.println("<div class='info-item'><div class='info-label'>Check-in</div><div class='info-value'>" + entrada + "</div></div>");
                out.println("<div class='info-item'><div class='info-label'>Check-out</div><div class='info-value'>" + salida + "</div></div>");
                out.println("</div>");
                out.println("</div>");
                
                // Cargos adicionales
                mostrarCargos(out, conn, numeroReserva);
                
                // Pagos
                mostrarPagos(out, conn, numeroReserva);
                
                // Estado de cuenta
                mostrarEstadoCuenta(out, conn, numeroReserva, precioBase);
                
                // Acciones
                out.println("<div class='card'>");
                out.println("<h2>⚙️ Acciones</h2>");
                
                if ("Pendiente".equals(estado)) {
                    out.println("<a href='CheckInOutServlet?id=" + numeroReserva + "&accion=checkin' class='btn btn-success'>✓ Realizar Check-in</a>");
                }
                if ("Activa".equals(estado)) {
                    out.println("<a href='CheckInOutServlet?id=" + numeroReserva + "&accion=checkout' class='btn btn-warning'>→ Realizar Check-out</a>");
                    out.println("<a href='agregar-cargo.jsp?id=" + numeroReserva + "' class='btn'>+ Agregar Cargo</a>");
                    out.println("<a href='agregar-pago.jsp?id=" + numeroReserva + "' class='btn btn-success'>+ Registrar Pago</a>");
                }
                
                out.println("<a href='BusquedaServlet?tipo=todas' class='btn'>← Volver a Reservas</a>");
                out.println("</div>");
                
            } else {
                out.println("<div class='card'><h1>❌ Reserva no encontrada</h1></div>");
            }
            
            out.println("</div>");
            out.println("</body></html>");
            
        } catch (Exception e) {
            Logger.error("Error mostrando detalle", e);
            out.println("<h2>Error: " + e.getMessage() + "</h2>");
        } finally {
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }
    
    private void mostrarCargos(PrintWriter out, Connection conn, int numeroReserva) throws SQLException {
        out.println("<div class='card'>");
        out.println("<h2>💳 Cargos Adicionales</h2>");
        
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT * FROM Cargo WHERE numeroReserva = ? ORDER BY fecha DESC");
        stmt.setInt(1, numeroReserva);
        ResultSet rs = stmt.executeQuery();
        
        out.println("<table>");
        out.println("<tr><th>Fecha</th><th>Descripción</th><th>Monto</th></tr>");
        
        int count = 0;
        while (rs.next()) {
            count++;
            out.println("<tr>");
            out.println("<td>" + rs.getTimestamp("fecha") + "</td>");
            out.println("<td>" + rs.getString("descripcion") + "</td>");
            out.println("<td>$" + String.format("%.2f", rs.getDouble("monto")) + "</td>");
            out.println("</tr>");
        }
        
        if (count == 0) {
            out.println("<tr><td colspan='3' style='text-align: center; color: #999;'>No hay cargos adicionales</td></tr>");
        }
        
        out.println("</table>");
        out.println("</div>");
    }
    
    private void mostrarPagos(PrintWriter out, Connection conn, int numeroReserva) throws SQLException {
        out.println("<div class='card'>");
        out.println("<h2>💰 Pagos Realizados</h2>");
        
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT * FROM Pago WHERE numeroReserva = ? ORDER BY fechaPago DESC");
        stmt.setInt(1, numeroReserva);
        ResultSet rs = stmt.executeQuery();
        
        out.println("<table>");
        out.println("<tr><th>Fecha</th><th>Método</th><th>Monto</th></tr>");
        
        int count = 0;
        while (rs.next()) {
            count++;
            out.println("<tr>");
            out.println("<td>" + rs.getTimestamp("fechaPago") + "</td>");
            out.println("<td>" + rs.getString("metodoPago") + "</td>");
            out.println("<td>$" + String.format("%.2f", rs.getDouble("monto")) + "</td>");
            out.println("</tr>");
        }
        
        if (count == 0) {
            out.println("<tr><td colspan='3' style='text-align: center; color: #999;'>No hay pagos registrados</td></tr>");
        }
        
        out.println("</table>");
        out.println("</div>");
    }
    
    private void mostrarEstadoCuenta(PrintWriter out, Connection conn, int numeroReserva, double precioBase) throws SQLException {
        // Calcular cargos
        PreparedStatement stmtCargos = conn.prepareStatement(
            "SELECT COALESCE(SUM(monto), 0) as total FROM Cargo WHERE numeroReserva = ?");
        stmtCargos.setInt(1, numeroReserva);
        ResultSet rsCargos = stmtCargos.executeQuery();
        double totalCargos = 0;
        if (rsCargos.next()) {
            totalCargos = rsCargos.getDouble("total");
        }
        
        // Calcular pagos
        PreparedStatement stmtPagos = conn.prepareStatement(
            "SELECT COALESCE(SUM(monto), 0) as total FROM Pago WHERE numeroReserva = ?");
        stmtPagos.setInt(1, numeroReserva);
        ResultSet rsPagos = stmtPagos.executeQuery();
        double totalPagos = 0;
        if (rsPagos.next()) {
            totalPagos = rsPagos.getDouble("total");
        }
        
        double totalGeneral = precioBase + totalCargos;
        double saldo = totalGeneral - totalPagos;
        
        out.println("<div class='card'>");
        out.println("<h2>📊 Estado de Cuenta</h2>");
        out.println("<table>");
        out.println("<tr><td><strong>Precio Base Habitación:</strong></td><td style='text-align: right;'>$" + String.format("%.2f", precioBase) + "</td></tr>");
        out.println("<tr><td><strong>Cargos Adicionales:</strong></td><td style='text-align: right;'>$" + String.format("%.2f", totalCargos) + "</td></tr>");
        out.println("<tr><td><strong>Total a Pagar:</strong></td><td style='text-align: right;'>$" + String.format("%.2f", totalGeneral) + "</td></tr>");
        out.println("<tr><td><strong>Pagos Realizados:</strong></td><td style='text-align: right; color: #27ae60;'>-$" + String.format("%.2f", totalPagos) + "</td></tr>");
        out.println("</table>");
        
        String colorSaldo = saldo > 0 ? "#e74c3c" : "#27ae60";
        out.println("<div class='total' style='color: " + colorSaldo + ";'>Saldo: $" + String.format("%.2f", saldo) + "</div>");
        out.println("</div>");
    }
}