package hotelmanagement.servlets;

import hotelmanagement.utils.Logger;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ReporteServlet")
public class ReporteServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String tipo = request.getParameter("tipo");
        
        Connection conn = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hoteldb", "root", "");
            
            out.println("<!DOCTYPE html>");
            out.println("<html><head>");
            out.println("<meta charset='UTF-8'>");
            out.println("<title>Reportes - Hotel System</title>");
            out.println("<style>");
            out.println("body { font-family: Arial; background: linear-gradient(135deg, rgba(44, 62, 80, 0.95) 0%, rgba(52, 73, 94, 0.95) 100%), url('https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1920&q=80') center/cover fixed; min-height: 100vh; padding: 20px; }");
            out.println(".container { max-width: 1400px; margin: 0 auto; }");
            out.println(".header { background: rgba(255,255,255,0.98); backdrop-filter: blur(20px); padding: 30px; border-radius: 15px; margin-bottom: 20px; box-shadow: 0 8px 32px rgba(0,0,0,0.15); }");
            out.println("h1 { color: #2c3e50; margin-bottom: 10px; }");
            out.println(".stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 20px; }");
            out.println(".stat-card { background: rgba(255,255,255,0.98); backdrop-filter: blur(20px); padding: 25px; border-radius: 15px; box-shadow: 0 8px 32px rgba(0,0,0,0.15); text-align: center; }");
            out.println(".stat-number { font-size: 2.5em; font-weight: bold; margin: 10px 0; }");
            out.println(".stat-label { color: #666; font-size: 0.9em; text-transform: uppercase; }");
            out.println(".stat-icon { font-size: 2em; margin-bottom: 10px; }");
            out.println(".green { color: #27ae60; }");
            out.println(".blue { color: #3498db; }");
            out.println(".orange { color: #f39c12; }");
            out.println(".red { color: #e74c3c; }");
            out.println(".card { background: rgba(255,255,255,0.98); backdrop-filter: blur(20px); padding: 30px; border-radius: 15px; margin-bottom: 20px; box-shadow: 0 8px 32px rgba(0,0,0,0.15); }");
            out.println("table { width: 100%; border-collapse: collapse; margin-top: 15px; }");
            out.println("th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }");
            out.println("th { background: #34495e; color: white; }");
            out.println("tr:hover { background: #f5f5f5; }");
            out.println(".btn { padding: 10px 20px; background: #3498db; color: white; border: none; border-radius: 8px; cursor: pointer; text-decoration: none; margin: 5px; display: inline-block; transition: all 0.3s; }");
            out.println(".btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4); }");
            out.println(".progress-bar { background: #ecf0f1; border-radius: 10px; height: 20px; overflow: hidden; margin: 10px 0; }");
            out.println(".progress-fill { height: 100%; background: linear-gradient(135deg, #3498db 0%, #2980b9 100%); transition: width 0.3s; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.85em; font-weight: bold; }");
            out.println(".menu-reportes { display: flex; gap: 10px; margin: 20px 0; flex-wrap: wrap; }");
            out.println(".btn-reporte { background: linear-gradient(135deg, #3498db 0%, #2980b9 100%); }");
            out.println(".btn-reporte.active { background: linear-gradient(135deg, #27ae60 0%, #229954 100%); }");
            out.println("</style>");
            out.println("</head><body>");
            out.println("<div class='container'>");
            
            // Menú de reportes
            out.println("<div class='header'>");
            out.println("<h1>📊 Reportes y Estadísticas</h1>");
            out.println("<div class='menu-reportes'>");
            out.println("<a href='ReporteServlet?tipo=dashboard' class='btn btn-reporte" + ("dashboard".equals(tipo) || tipo == null ? " active" : "") + "'>Dashboard General</a>");
            out.println("<a href='ReporteServlet?tipo=ocupacion' class='btn btn-reporte" + ("ocupacion".equals(tipo) ? " active" : "") + "'>Ocupación</a>");
            out.println("<a href='ReporteServlet?tipo=ingresos' class='btn btn-reporte" + ("ingresos".equals(tipo) ? " active" : "") + "'>Ingresos</a>");
            out.println("<a href='ReporteServlet?tipo=disponibilidad' class='btn btn-reporte" + ("disponibilidad".equals(tipo) ? " active" : "") + "'>Disponibilidad</a>");
            out.println("<a href='ReporteServlet?tipo=clientes' class='btn btn-reporte" + ("clientes".equals(tipo) ? " active" : "") + "'>Top Clientes</a>");
            out.println("<a href='dashboard.jsp' class='btn'>← Volver</a>");
            out.println("</div>");
            out.println("</div>");
            
            if (tipo == null || "dashboard".equals(tipo)) {
                mostrarDashboard(out, conn);
            } else if ("ocupacion".equals(tipo)) {
                reporteOcupacion(out, conn);
            } else if ("ingresos".equals(tipo)) {
                reporteIngresos(out, conn);
            } else if ("disponibilidad".equals(tipo)) {
                reporteDisponibilidad(out, conn);
            } else if ("clientes".equals(tipo)) {
                reporteClientes(out, conn);
            }
            
            out.println("</div>");
            out.println("</body></html>");
            
        } catch (Exception e) {
            Logger.error("Error en reportes", e);
            out.println("<h2>Error: " + e.getMessage() + "</h2>");
        } finally {
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }
    
    private void mostrarDashboard(PrintWriter out, Connection conn) throws SQLException {
        // Estadísticas principales
        out.println("<div class='stats-grid'>");
        
        // Total habitaciones
        PreparedStatement stmtTotal = conn.prepareStatement("SELECT COUNT(*) as total FROM Habitacion");
        ResultSet rsTotal = stmtTotal.executeQuery();
        int totalHabitaciones = rsTotal.next() ? rsTotal.getInt("total") : 0;
        
        // Habitaciones ocupadas
        PreparedStatement stmtOcupadas = conn.prepareStatement("SELECT COUNT(*) as ocupadas FROM Habitacion WHERE estado = 'Ocupada'");
        ResultSet rsOcupadas = stmtOcupadas.executeQuery();
        int ocupadas = rsOcupadas.next() ? rsOcupadas.getInt("ocupadas") : 0;
        
        // Habitaciones disponibles
        int disponibles = totalHabitaciones - ocupadas;
        
        // Porcentaje de ocupación
        double porcentajeOcupacion = totalHabitaciones > 0 ? (ocupadas * 100.0 / totalHabitaciones) : 0;
        
        // Total reservas
        PreparedStatement stmtReservas = conn.prepareStatement("SELECT COUNT(*) as total FROM Reserva");
        ResultSet rsReservas = stmtReservas.executeQuery();
        int totalReservas = rsReservas.next() ? rsReservas.getInt("total") : 0;
        
        // Reservas activas
        PreparedStatement stmtActivas = conn.prepareStatement("SELECT COUNT(*) as activas FROM Reserva WHERE estadoReserva = 'Activa'");
        ResultSet rsActivas = stmtActivas.executeQuery();
        int reservasActivas = rsActivas.next() ? rsActivas.getInt("activas") : 0;
        
        // Ingresos totales
        PreparedStatement stmtIngresos = conn.prepareStatement("SELECT COALESCE(SUM(precioTotal), 0) as total FROM Reserva");
        ResultSet rsIngresos = stmtIngresos.executeQuery();
        double ingresosTotal = rsIngresos.next() ? rsIngresos.getDouble("total") : 0;
        
        // Ingresos cargos
        PreparedStatement stmtCargos = conn.prepareStatement("SELECT COALESCE(SUM(monto), 0) as total FROM Cargo");
        ResultSet rsCargos = stmtCargos.executeQuery();
        double ingresosCargos = rsCargos.next() ? rsCargos.getDouble("total") : 0;
        
        double ingresosTotales = ingresosTotal + ingresosCargos;
        
        // Tarjetas de estadísticas
        out.println("<div class='stat-card'>");
        out.println("<div class='stat-icon green'>🏨</div>");
        out.println("<div class='stat-number green'>" + disponibles + "</div>");
        out.println("<div class='stat-label'>Habitaciones Disponibles</div>");
        out.println("</div>");
        
        out.println("<div class='stat-card'>");
        out.println("<div class='stat-icon orange'>🔑</div>");
        out.println("<div class='stat-number orange'>" + ocupadas + "</div>");
        out.println("<div class='stat-label'>Habitaciones Ocupadas</div>");
        out.println("</div>");
        
        out.println("<div class='stat-card'>");
        out.println("<div class='stat-icon blue'>📅</div>");
        out.println("<div class='stat-number blue'>" + reservasActivas + "</div>");
        out.println("<div class='stat-label'>Reservas Activas</div>");
        out.println("</div>");
        
        out.println("<div class='stat-card'>");
        out.println("<div class='stat-icon green'>💰</div>");
        out.println("<div class='stat-number green'>$" + String.format("%.2f", ingresosTotales) + "</div>");
        out.println("<div class='stat-label'>Ingresos Totales</div>");
        out.println("</div>");
        
        out.println("</div>");
        
        // Ocupación visual
        out.println("<div class='card'>");
        out.println("<h2>📊 Ocupación Actual</h2>");
        out.println("<div class='progress-bar'>");
        out.println("<div class='progress-fill' style='width: " + porcentajeOcupacion + "%;'>" + String.format("%.1f", porcentajeOcupacion) + "%</div>");
        out.println("</div>");
        out.println("<p style='color: #666; text-align: center; margin-top: 10px;'>" + ocupadas + " de " + totalHabitaciones + " habitaciones ocupadas</p>");
        out.println("</div>");
        
        // Últimas reservas
        out.println("<div class='card'>");
        out.println("<h2>📋 Últimas 5 Reservas</h2>");
        PreparedStatement stmtUltimas = conn.prepareStatement(
            "SELECT * FROM Reserva ORDER BY numeroReserva DESC LIMIT 5");
        ResultSet rsUltimas = stmtUltimas.executeQuery();
        
        out.println("<table>");
        out.println("<tr><th>ID</th><th>Habitación</th><th>Cliente</th><th>Estado</th><th>Precio</th></tr>");
        
        while (rsUltimas.next()) {
            out.println("<tr>");
            out.println("<td>#" + rsUltimas.getInt("numeroReserva") + "</td>");
            out.println("<td>Hab " + rsUltimas.getInt("numeroHabitacion") + "</td>");
            out.println("<td>" + rsUltimas.getString("nombreOcupante") + "</td>");
            out.println("<td>" + (rsUltimas.getString("estadoReserva") != null ? rsUltimas.getString("estadoReserva") : "Pendiente") + "</td>");
            out.println("<td>$" + String.format("%.2f", rsUltimas.getDouble("precioTotal")) + "</td>");
            out.println("</tr>");
        }
        out.println("</table>");
        out.println("</div>");
    }
    
    private void reporteOcupacion(PrintWriter out, Connection conn) throws SQLException {
        out.println("<div class='card'>");
        out.println("<h2>🔑 Reporte de Ocupación por Habitación</h2>");
        
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT h.numeroHabitacion, h.tipo, h.estado, h.precio, " +
            "COUNT(r.numeroReserva) as totalReservas " +
            "FROM Habitacion h " +
            "LEFT JOIN Reserva r ON h.numeroHabitacion = r.numeroHabitacion " +
            "GROUP BY h.numeroHabitacion " +
            "ORDER BY h.numeroHabitacion");
        ResultSet rs = stmt.executeQuery();
        
        out.println("<table>");
        out.println("<tr><th>Habitación</th><th>Tipo</th><th>Estado</th><th>Precio/Noche</th><th>Total Reservas</th></tr>");
        
        while (rs.next()) {
            String estado = rs.getString("estado");
            String colorEstado = "Disponible".equals(estado) ? "green" : "orange";
            
            out.println("<tr>");
            out.println("<td><strong>Hab " + rs.getInt("numeroHabitacion") + "</strong></td>");
            out.println("<td>" + (rs.getString("tipo") != null ? rs.getString("tipo") : "Estándar") + "</td>");
            out.println("<td style='color: " + colorEstado + "; font-weight: bold;'>" + estado + "</td>");
            out.println("<td>$" + String.format("%.2f", rs.getDouble("precio")) + "</td>");
            out.println("<td>" + rs.getInt("totalReservas") + "</td>");
            out.println("</tr>");
        }
        out.println("</table>");
        out.println("</div>");
    }
    
    private void reporteIngresos(PrintWriter out, Connection conn) throws SQLException {
        out.println("<div class='card'>");
        out.println("<h2>💰 Reporte de Ingresos</h2>");
        
        // Ingresos por reservas
        PreparedStatement stmtReservas = conn.prepareStatement(
            "SELECT estadoReserva, COUNT(*) as cantidad, SUM(precioTotal) as total " +
            "FROM Reserva GROUP BY estadoReserva");
        ResultSet rsReservas = stmtReservas.executeQuery();
        
        out.println("<h3>Por Reservas</h3>");
        out.println("<table>");
        out.println("<tr><th>Estado</th><th>Cantidad</th><th>Total</th></tr>");
        
        double totalReservas = 0;
        while (rsReservas.next()) {
            double total = rsReservas.getDouble("total");
            totalReservas += total;
            out.println("<tr>");
            out.println("<td>" + (rsReservas.getString("estadoReserva") != null ? rsReservas.getString("estadoReserva") : "Pendiente") + "</td>");
            out.println("<td>" + rsReservas.getInt("cantidad") + "</td>");
            out.println("<td>$" + String.format("%.2f", total) + "</td>");
            out.println("</tr>");
        }
        out.println("<tr style='font-weight: bold; background: #ecf0f1;'>");
        out.println("<td colspan='2'>TOTAL RESERVAS</td>");
        out.println("<td>$" + String.format("%.2f", totalReservas) + "</td>");
        out.println("</tr>");
        out.println("</table>");
        
        // Ingresos por cargos adicionales
        PreparedStatement stmtCargos = conn.prepareStatement(
            "SELECT descripcion, COUNT(*) as cantidad, SUM(monto) as total " +
            "FROM Cargo GROUP BY descripcion ORDER BY total DESC");
        ResultSet rsCargos = stmtCargos.executeQuery();
        
        out.println("<h3 style='margin-top: 30px;'>Por Cargos Adicionales</h3>");
        out.println("<table>");
        out.println("<tr><th>Concepto</th><th>Cantidad</th><th>Total</th></tr>");
        
        double totalCargos = 0;
        while (rsCargos.next()) {
            double total = rsCargos.getDouble("total");
            totalCargos += total;
            out.println("<tr>");
            out.println("<td>" + rsCargos.getString("descripcion") + "</td>");
            out.println("<td>" + rsCargos.getInt("cantidad") + "</td>");
            out.println("<td>$" + String.format("%.2f", total) + "</td>");
            out.println("</tr>");
        }
        out.println("<tr style='font-weight: bold; background: #ecf0f1;'>");
        out.println("<td colspan='2'>TOTAL CARGOS</td>");
        out.println("<td>$" + String.format("%.2f", totalCargos) + "</td>");
        out.println("</tr>");
        out.println("</table>");
        
        // Total general
        double totalGeneral = totalReservas + totalCargos;
        out.println("<div style='margin-top: 30px; padding: 20px; background: #27ae60; color: white; border-radius: 10px; text-align: center;'>");
        out.println("<h2 style='color: white; margin: 0;'>INGRESOS TOTALES: $" + String.format("%.2f", totalGeneral) + "</h2>");
        out.println("</div>");
        out.println("</div>");
    }
    
    private void reporteDisponibilidad(PrintWriter out, Connection conn) throws SQLException {
        out.println("<div class='card'>");
        out.println("<h2>🏨 Disponibilidad de Habitaciones</h2>");
        
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT * FROM Habitacion WHERE estado = 'Disponible' ORDER BY precio");
        ResultSet rs = stmt.executeQuery();
        
        out.println("<table>");
        out.println("<tr><th>Habitación</th><th>Tipo</th><th>Precio/Noche</th><th>Acción</th></tr>");
        
        int count = 0;
        while (rs.next()) {
            count++;
            int numHab = rs.getInt("numeroHabitacion");
            out.println("<tr>");
            out.println("<td><strong>Hab " + numHab + "</strong></td>");
            out.println("<td>" + (rs.getString("tipo") != null ? rs.getString("tipo") : "Estándar") + "</td>");
            out.println("<td>$" + String.format("%.2f", rs.getDouble("precio")) + "</td>");
            out.println("<td><a href='dashboard.jsp' class='btn'>Reservar</a></td>");
            out.println("</tr>");
        }
        
        if (count == 0) {
            out.println("<tr><td colspan='4' style='text-align: center; padding: 20px; color: #e74c3c;'>⚠️ No hay habitaciones disponibles</td></tr>");
        } else {
            out.println("<tr style='background: #ecf0f1; font-weight: bold;'>");
            out.println("<td colspan='4'>" + count + " habitación(es) disponible(s)</td>");
            out.println("</tr>");
        }
        
        out.println("</table>");
        out.println("</div>");
    }
    
    private void reporteClientes(PrintWriter out, Connection conn) throws SQLException {
        out.println("<div class='card'>");
        out.println("<h2>👥 Top 10 Clientes Frecuentes</h2>");
        
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT nombreOcupante, COUNT(*) as visitas, SUM(precioTotal) as totalGastado " +
            "FROM Reserva " +
            "GROUP BY nombreOcupante " +
            "ORDER BY visitas DESC, totalGastado DESC " +
            "LIMIT 10");
        ResultSet rs = stmt.executeQuery();
        
        out.println("<table>");
        out.println("<tr><th>Posición</th><th>Cliente</th><th>Visitas</th><th>Total Gastado</th></tr>");
        
        int pos = 1;
        while (rs.next()) {
            String emoji = pos <= 3 ? (pos == 1 ? "🥇" : pos == 2 ? "🥈" : "🥉") : String.valueOf(pos);
            out.println("<tr>");
            out.println("<td>" + emoji + "</td>");
            out.println("<td><strong>" + rs.getString("nombreOcupante") + "</strong></td>");
            out.println("<td>" + rs.getInt("visitas") + " visita(s)</td>");
            out.println("<td style='color: #27ae60; font-weight: bold;'>$" + String.format("%.2f", rs.getDouble("totalGastado")) + "</td>");
            out.println("</tr>");
            pos++;
        }
        
        out.println("</table>");
        out.println("</div>");
    }
}