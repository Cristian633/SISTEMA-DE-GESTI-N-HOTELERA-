package hotelmanagement.servlets;

import hotelmanagement.utils.Logger;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BusquedaServlet")
public class BusquedaServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String tipo = request.getParameter("tipo");
        String busqueda = request.getParameter("busqueda");
        
        Connection conn = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hoteldb", "root", "");
            
            out.println("<!DOCTYPE html>");
            out.println("<html><head>");
            out.println("<title>Búsqueda de Reservas</title>");
            out.println("<style>");
            out.println("body { font-family: Arial; background: linear-gradient(135deg, rgba(44, 62, 80, 0.95) 0%, rgba(52, 73, 94, 0.95) 100%), url('https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1920&q=80') center/cover fixed; min-height: 100vh; padding: 20px; }");
            out.println(".container { max-width: 1200px; margin: 0 auto; background: rgba(255,255,255,0.98); backdrop-filter: blur(20px); padding: 30px; border-radius: 15px; }");
            out.println("h1 { color: #2c3e50; margin-bottom: 20px; }");
            out.println("table { width: 100%; border-collapse: collapse; margin-top: 20px; }");
            out.println("th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }");
            out.println("th { background: linear-gradient(135deg, #3498db 0%, #2980b9 100%); color: white; }");
            out.println("tr:hover { background: #f5f5f5; }");
            out.println(".btn { padding: 8px 15px; background: #3498db; color: white; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; margin: 2px; display: inline-block; }");
            out.println(".btn-danger { background: #e74c3c; }");
            out.println(".btn-success { background: #27ae60; }");
            out.println(".btn-back { margin-top: 20px; }");
            out.println(".estado { padding: 5px 10px; border-radius: 5px; font-size: 0.85em; font-weight: bold; }");
            out.println(".estado-pendiente { background: #f39c12; color: white; }");
            out.println(".estado-activa { background: #27ae60; color: white; }");
            out.println(".estado-completada { background: #95a5a6; color: white; }");
            out.println(".estado-cancelada { background: #e74c3c; color: white; }");
            out.println("</style>");
            out.println("</head><body>");
            out.println("<div class='container'>");
            
            if ("todas".equals(tipo)) {
                Logger.info("Listando todas las reservas");
                mostrarTodasReservas(out, conn);
            } else if ("habitacion".equals(tipo) && busqueda != null) {
                Logger.info("Buscando reservas por habitación: " + busqueda);
                buscarPorHabitacion(out, conn, Integer.parseInt(busqueda));
            } else if ("nombre".equals(tipo) && busqueda != null) {
                Logger.info("Buscando reservas por nombre: " + busqueda);
                buscarPorNombre(out, conn, busqueda);
            } else if ("activas".equals(tipo)) {
                Logger.info("Listando reservas activas");
                mostrarReservasActivas(out, conn);
            } else {
                out.println("<h1>❌ Parámetros inválidos</h1>");
            }
            
            out.println("<br><a href='dashboard.jsp' class='btn btn-back'>← Volver al Dashboard</a>");
            out.println("</div>");
            out.println("</body></html>");
            
        } catch (Exception e) {
            Logger.error("Error en búsqueda", e);
            out.println("<h2>Error: " + e.getMessage() + "</h2>");
        } finally {
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }
    
    private void mostrarTodasReservas(PrintWriter out, Connection conn) throws SQLException {
        out.println("<h1>📋 Todas las Reservas</h1>");
        
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT * FROM Reserva ORDER BY numeroReserva DESC");
        ResultSet rs = stmt.executeQuery();
        
        mostrarTablaReservas(out, rs);
    }
    
    private void mostrarReservasActivas(PrintWriter out, Connection conn) throws SQLException {
        out.println("<h1>📋 Reservas Activas y Pendientes</h1>");
        
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT * FROM Reserva WHERE (estadoReserva = 'Activa' OR estadoReserva = 'Pendiente' OR estadoReserva IS NULL) ORDER BY fechaEntrada");
        ResultSet rs = stmt.executeQuery();
        
        mostrarTablaReservas(out, rs);
    }
    
    private void buscarPorHabitacion(PrintWriter out, Connection conn, int numeroHabitacion) throws SQLException {
        out.println("<h1>🔍 Reservas para Habitación #" + numeroHabitacion + "</h1>");
        
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT * FROM Reserva WHERE numeroHabitacion = ? ORDER BY fechaEntrada DESC");
        stmt.setInt(1, numeroHabitacion);
        ResultSet rs = stmt.executeQuery();
        
        mostrarTablaReservas(out, rs);
    }
    
    private void buscarPorNombre(PrintWriter out, Connection conn, String nombre) throws SQLException {
        out.println("<h1>🔍 Resultados para: \"" + nombre + "\"</h1>");
        
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT * FROM Reserva WHERE nombreOcupante LIKE ? ORDER BY fechaEntrada DESC");
        stmt.setString(1, "%" + nombre + "%");
        ResultSet rs = stmt.executeQuery();
        
        mostrarTablaReservas(out, rs);
    }
    
    private void mostrarTablaReservas(PrintWriter out, ResultSet rs) throws SQLException {
        out.println("<table>");
        out.println("<tr>");
        out.println("<th>ID</th>");
        out.println("<th>Habitación</th>");
        out.println("<th>Cliente</th>");
        out.println("<th>Check-in</th>");
        out.println("<th>Check-out</th>");
        out.println("<th>Estado</th>");
        out.println("<th>Precio</th>");
        out.println("<th>Acciones</th>");
        out.println("</tr>");
        
        int count = 0;
        while (rs.next()) {
            count++;
            int id = rs.getInt("numeroReserva");
            int hab = rs.getInt("numeroHabitacion");
            String nombre = rs.getString("nombreOcupante");
            Date entrada = rs.getDate("fechaEntrada");
            Date salida = rs.getDate("fechaSalida");
            String estado = rs.getString("estadoReserva");
            if (estado == null) estado = "Pendiente";
            double precio = rs.getDouble("precioTotal");
            
            String estadoClass = "estado-" + estado.toLowerCase();
            
            out.println("<tr>");
            out.println("<td>#" + id + "</td>");
            out.println("<td>Hab " + hab + "</td>");
            out.println("<td>" + nombre + "</td>");
            out.println("<td>" + entrada + "</td>");
            out.println("<td>" + salida + "</td>");
            out.println("<td><span class='estado " + estadoClass + "'>" + estado + "</span></td>");
            out.println("<td>$" + String.format("%.2f", precio) + "</td>");
            out.println("<td>");
            out.println("<a href='DetalleReservaServlet?id=" + id + "' class='btn'>Ver Detalle</a>");
            if ("Activa".equals(estado) || "Pendiente".equals(estado)) {
                out.println("<a href='CheckInOutServlet?id=" + id + "&accion=checkin' class='btn btn-success'>Check-in</a>");
            }
            out.println("</td>");
            out.println("</tr>");
        }
        
        if (count == 0) {
            out.println("<tr><td colspan='8' style='text-align: center; padding: 20px; color: #999;'>No se encontraron reservas</td></tr>");
        }
        
        out.println("</table>");
        out.println("<p style='margin-top: 15px; color: #666;'>Total: " + count + " reserva(s) encontrada(s)</p>");
    }
}