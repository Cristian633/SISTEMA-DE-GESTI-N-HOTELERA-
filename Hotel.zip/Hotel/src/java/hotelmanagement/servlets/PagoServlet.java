package hotelmanagement.servlets;

import hotelmanagement.utils.Logger;
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PagoServlet")
public class PagoServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String idStr = request.getParameter("numeroReserva");
        String montoStr = request.getParameter("monto");
        String metodoPago = request.getParameter("metodoPago");
        
        if (idStr == null || montoStr == null || metodoPago == null) {
            response.sendRedirect("dashboard.jsp");
            return;
        }
        
        int numeroReserva = Integer.parseInt(idStr);
        double monto = Double.parseDouble(montoStr);
        
        Connection conn = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hoteldb", "root", "");
            
            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO Pago (numeroReserva, monto, metodoPago) VALUES (?, ?, ?)");
            stmt.setInt(1, numeroReserva);
            stmt.setDouble(2, monto);
            stmt.setString(3, metodoPago);
            stmt.executeUpdate();
            
            Logger.info("✓ Pago registrado - Reserva #" + numeroReserva + ": $" + monto + " (" + metodoPago + ")");
            Logger.logAccion("Sistema", "PAGO_REGISTRADO", "Reserva #" + numeroReserva + " - $" + monto);
            
            response.sendRedirect("DetalleReservaServlet?id=" + numeroReserva + "&msg=pago");
            
        } catch (Exception e) {
            Logger.error("Error registrando pago", e);
            response.sendRedirect("dashboard.jsp");
        } finally {
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }
}