package hotelmanagement.servlets;

import hotelmanagement.utils.Logger;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CheckInOutServlet")
public class CheckInOutServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String idStr = request.getParameter("id");
        String accion = request.getParameter("accion");
        
        if (idStr == null || accion == null) {
            response.sendRedirect("dashboard.jsp");
            return;
        }
        
        int numeroReserva = Integer.parseInt(idStr);
        Connection conn = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hoteldb", "root", "");
            
            if ("checkin".equals(accion)) {
                realizarCheckIn(conn, numeroReserva);
                Logger.info("✓ Check-in realizado - Reserva #" + numeroReserva);
                response.sendRedirect("DetalleReservaServlet?id=" + numeroReserva + "&msg=checkin");
            } else if ("checkout".equals(accion)) {
                realizarCheckOut(conn, numeroReserva);
                Logger.info("✓ Check-out realizado - Reserva #" + numeroReserva);
                response.sendRedirect("DetalleReservaServlet?id=" + numeroReserva + "&msg=checkout");
            }
            
        } catch (Exception e) {
            Logger.error("Error en check-in/out", e);
            response.sendRedirect("dashboard.jsp");
        } finally {
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }
    
    private void realizarCheckIn(Connection conn, int numeroReserva) throws SQLException {
        PreparedStatement stmt = conn.prepareStatement(
            "UPDATE Reserva SET estadoReserva = 'Activa' WHERE numeroReserva = ?");
        stmt.setInt(1, numeroReserva);
        stmt.executeUpdate();
    }
    
    private void realizarCheckOut(Connection conn, int numeroReserva) throws SQLException {
        // Actualizar estado de reserva
        PreparedStatement stmt = conn.prepareStatement(
            "UPDATE Reserva SET estadoReserva = 'Completada' WHERE numeroReserva = ?");
        stmt.setInt(1, numeroReserva);
        stmt.executeUpdate();
        
        // Liberar habitación
        PreparedStatement stmt2 = conn.prepareStatement(
            "UPDATE Habitacion h SET h.estado = 'Disponible' " +
            "WHERE h.numeroHabitacion = (SELECT numeroHabitacion FROM Reserva WHERE numeroReserva = ?)");
        stmt2.setInt(1, numeroReserva);
        stmt2.executeUpdate();
    }
}