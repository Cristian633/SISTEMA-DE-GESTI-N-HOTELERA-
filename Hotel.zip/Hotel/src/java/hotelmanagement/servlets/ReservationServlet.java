package hotelmanagement.servlets;

import hotelmanagement.HotelManagement;
import hotelmanagement.utils.Logger;
import hotelmanagement.utils.validator;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ReservationServlet")
public class ReservationServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        HotelManagement hotel = null;

        try {
            // Inicializar conexión para esta petición
            hotel = new HotelManagement();
            Logger.info("Nueva petición recibida");
            
            String action = request.getParameter("action");
            
            if ("reserve".equals(action)) {
                procesarReserva(request, response, out, hotel);
            } else if ("delete".equals(action)) {
                procesarBorrado(request, response, out, hotel);
            } else {
                Logger.warning("Acción desconocida: " + action);
                out.println("<h2>Error: Acción no válida</h2>");
            }
            
        } catch (NumberFormatException e) {
            Logger.error("Error de formato numérico", e);
            out.println("<h2>Error: El número de habitación o reserva debe ser un valor numérico</h2>");
        } catch (Exception e) {
            Logger.error("Error general en servlet", e);
            out.println("<h2>Error: " + e.getMessage() + "</h2>");
        } finally {
            if (hotel != null) {
                hotel.cerrarConexion();
            }
            out.close();
        }
    }
    
    /**
     * Procesa una nueva reserva con validaciones
     */
    private void procesarReserva(HttpServletRequest request, HttpServletResponse response,
                                 PrintWriter out, HotelManagement hotel) {
        try {
            // Obtener parámetros
            String roomNumberStr = request.getParameter("roomNumber");
            String guestName = request.getParameter("guestName");
            String telefono = request.getParameter("telefono");
            String email = request.getParameter("email");
            String checkIn = request.getParameter("checkIn");
            String checkOut = request.getParameter("checkOut");

            // VALIDACIÓN 1: Campos obligatorios
            if (!validator.esTextoValido(roomNumberStr) || 
                !validator.esTextoValido(guestName) || 
                !validator.esTextoValido(checkIn) || 
                !validator.esTextoValido(checkOut)) {
                
                Logger.warning("Intento de reserva con campos vacíos");
                out.println("<html><body style='font-family: Arial; padding: 20px;'>");
                out.println("<h2 style='color: #c33;'>❌ Error: Los campos obligatorios están vacíos</h2>");
                out.println("<a href='dashboard.jsp' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>← Volver al inicio</a>");
                out.println("</body></html>");
                return;
            }
            
            // VALIDACIÓN: Email (opcional pero si viene debe ser válido)
            if (email != null && !email.trim().isEmpty() && !validator.esEmailValido(email)) {
                Logger.warning("Email inválido: " + email);
                out.println("<html><body style='font-family: Arial; padding: 20px;'>");
                out.println("<h2 style='color: #c33;'>❌ Error: El email no es válido</h2>");
                out.println("<a href='dashboard.jsp' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>← Volver al inicio</a>");
                out.println("</body></html>");
                return;
            }
            
            // VALIDACIÓN: Teléfono (opcional pero si viene debe ser válido)
            if (telefono != null && !telefono.trim().isEmpty() && !validator.esTelefonoValido(telefono)) {
                Logger.warning("Teléfono inválido: " + telefono);
                out.println("<html><body style='font-family: Arial; padding: 20px;'>");
                out.println("<h2 style='color: #c33;'>❌ Error: El teléfono no es válido (8-15 dígitos)</h2>");
                out.println("<a href='dashboard.jsp' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>← Volver al inicio</a>");
                out.println("</body></html>");
                return;
            }

            // Sanitizar nombre
            guestName = validator.sanitizarTexto(guestName);
            
            // VALIDACIÓN 2: Nombre válido
            String errorNombre = validator.validarNombreOcupante(guestName);
            if (errorNombre != null) {
                Logger.warning("Nombre inválido: " + guestName + " - " + errorNombre);
                out.println("<html><body style='font-family: Arial; padding: 20px;'>");
                out.println("<h2 style='color: #c33;'>❌ Error: " + errorNombre + "</h2>");
                out.println("<a href='dashboard.jsp' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>← Volver al inicio</a>");
                out.println("</body></html>");
                return;
            }

            // Parsear número de habitación
            int roomNumber = Integer.parseInt(roomNumberStr);
            
            // VALIDACIÓN 3: Número de habitación válido
            if (!validator.esNumeroHabitacionValido(roomNumber)) {
                Logger.warning("Número de habitación inválido: " + roomNumber);
                out.println("<html><body style='font-family: Arial; padding: 20px;'>");
                out.println("<h2 style='color: #c33;'>❌ Error: El número de habitación debe estar entre 1 y 100</h2>");
                out.println("<a href='dashboard.jsp' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>← Volver al inicio</a>");
                out.println("</body></html>");
                return;
            }

            // Parsear fechas
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date checkInDate = sdf.parse(checkIn);
            Date checkOutDate = sdf.parse(checkOut);

            // VALIDACIÓN 4: Fechas válidas
            String errorFechas = validator.validarFechas(checkInDate, checkOutDate);
            if (errorFechas != null) {
                Logger.warning("Fechas inválidas para hab " + roomNumber + ": " + errorFechas);
                out.println("<html><body style='font-family: Arial; padding: 20px;'>");
                out.println("<h2 style='color: #c33;'>❌ Error: " + errorFechas + "</h2>");
                out.println("<a href='dashboard.jsp' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>← Volver al inicio</a>");
                out.println("</body></html>");
                return;
            }

            // Todo validado, proceder con la reserva
            Logger.info("Intentando reserva - Hab: " + roomNumber + ", Cliente: " + guestName);
            
            if (hotel.verificarDisponibilidad(roomNumber)) {
                // Calcular precio total
                long dias = (checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24);
                double precioTotal = calcularPrecioTotal(roomNumber, dias);
                
                hotel.hacerReservaCompleta(roomNumber, guestName, telefono, email, checkIn, checkOut, precioTotal);
                
                // Obtener el número de reserva recién creado
                int numeroReserva = obtenerUltimaReserva(roomNumber);
                
                Logger.info("✓ Reserva exitosa - #" + numeroReserva + " Hab: " + roomNumber + ", Cliente: " + guestName);
                Logger.logAccion(guestName, "RESERVA_CREADA", 
                    "Reserva #" + numeroReserva + " - Habitación " + roomNumber + " del " + 
                    validator.formatearFecha(checkInDate) + " al " + 
                    validator.formatearFecha(checkOutDate));
                
                out.println("<html><head><style>");
                out.println("body { font-family: Arial; padding: 40px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }");
                out.println(".success-card { background: white; border-radius: 15px; padding: 40px; max-width: 500px; margin: 0 auto; box-shadow: 0 10px 40px rgba(0,0,0,0.2); }");
                out.println(".success-card h2 { color: #4CAF50; margin-bottom: 20px; }");
                out.println(".info-row { padding: 12px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; }");
                out.println(".info-row:last-of-type { border-bottom: none; }");
                out.println(".label { color: #666; font-weight: 600; }");
                out.println(".value { color: #333; }");
                out.println(".reservation-number { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px; border-radius: 10px; text-align: center; margin: 20px 0; font-size: 1.2em; }");
                out.println(".btn-back { display: inline-block; margin-top: 20px; padding: 12px 30px; background: #4CAF50; color: white; text-decoration: none; border-radius: 8px; transition: all 0.3s; }");
                out.println(".btn-back:hover { background: #45a049; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(76, 175, 80, 0.4); }");
                out.println("</style></head><body>");
                out.println("<div class='success-card'>");
                out.println("<h2>✓ Reserva Exitosa</h2>");
                out.println("<div class='reservation-number'>");
                out.println("<strong>Número de Reserva:</strong> #" + numeroReserva);
                out.println("</div>");
                out.println("<div class='info-row'><span class='label'>Cliente:</span><span class='value'>" + guestName + "</span></div>");
                out.println("<div class='info-row'><span class='label'>Habitación:</span><span class='value'>#" + roomNumber + "</span></div>");
                if (telefono != null && !telefono.trim().isEmpty()) {
                    out.println("<div class='info-row'><span class='label'>Teléfono:</span><span class='value'>" + telefono + "</span></div>");
                }
                if (email != null && !email.trim().isEmpty()) {
                    out.println("<div class='info-row'><span class='label'>Email:</span><span class='value'>" + email + "</span></div>");
                }
                out.println("<div class='info-row'><span class='label'>Check-in:</span><span class='value'>" + validator.formatearFecha(checkInDate) + "</span></div>");
                out.println("<div class='info-row'><span class='label'>Check-out:</span><span class='value'>" + validator.formatearFecha(checkOutDate) + "</span></div>");
                out.println("<div class='info-row'><span class='label'>Días:</span><span class='value'>" + dias + "</span></div>");
                out.println("<div class='info-row'><span class='label'>Precio Total:</span><span class='value' style='color: #27ae60; font-weight: bold;'>$" + String.format("%.2f", precioTotal) + "</span></div>");
                out.println("<p style='margin-top: 20px; color: #666; font-size: 0.9em;'>💡 Guarda el número de reserva <strong>#" + numeroReserva + "</strong> para futuras referencias o cancelaciones.</p>");
                out.println("<a href='dashboard.jsp' class='btn-back'>← Volver al Dashboard</a>");
                out.println("</div>");
                out.println("</body></html>");
            } else {
                Logger.warning("Habitación " + roomNumber + " no disponible");
                out.println("<html><body style='font-family: Arial; padding: 20px;'>");
                out.println("<h2 style='color: #c33;'>❌ No hay disponibilidad en la habitación " + roomNumber + "</h2>");
                out.println("<a href='dashboard.jsp' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>← Volver al inicio</a>");
                out.println("</body></html>");
            }
            
        } catch (Exception e) {
            Logger.error("Error procesando reserva", e);
            out.println("<html><body style='font-family: Arial; padding: 20px;'>");
            out.println("<h2 style='color: #c33;'>❌ Error: " + e.getMessage() + "</h2>");
            out.println("<a href='dashboard.jsp' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>← Volver al inicio</a>");
            out.println("</body></html>");
        }
    }
    
    /**
     * Obtiene el número de la última reserva creada para una habitación
     */
    private int obtenerUltimaReserva(int numeroHabitacion) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            java.sql.Connection conn = java.sql.DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/hoteldb", "root", "");
            
            java.sql.PreparedStatement stmt = conn.prepareStatement(
                "SELECT numeroReserva FROM Reserva WHERE numeroHabitacion = ? ORDER BY numeroReserva DESC LIMIT 1");
            stmt.setInt(1, numeroHabitacion);
            
            java.sql.ResultSet rs = stmt.executeQuery();
            int numeroReserva = 0;
            
            if (rs.next()) {
                numeroReserva = rs.getInt("numeroReserva");
            }
            
            conn.close();
            return numeroReserva;
            
        } catch (Exception e) {
            Logger.error("Error obteniendo número de reserva", e);
            return 0;
        }
    }
    
    /**
     * Calcula el precio total de la reserva
     */
    private double calcularPrecioTotal(int numeroHabitacion, long dias) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            java.sql.Connection conn = java.sql.DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/hoteldb", "root", "");
            
            java.sql.PreparedStatement stmt = conn.prepareStatement(
                "SELECT precio FROM Habitacion WHERE numeroHabitacion = ?");
            stmt.setInt(1, numeroHabitacion);
            
            java.sql.ResultSet rs = stmt.executeQuery();
            double precioTotal = 0;
            
            if (rs.next()) {
                double precioPorNoche = rs.getDouble("precio");
                precioTotal = precioPorNoche * dias;
            }
            
            conn.close();
            return precioTotal;
            
        } catch (Exception e) {
            Logger.error("Error calculando precio", e);
            return 0;
        }
    }
    
    /**
     * Procesa el borrado de una reserva
     */
    private void procesarBorrado(HttpServletRequest request, HttpServletResponse response,
                                PrintWriter out, HotelManagement hotel) {
        try {
            String reservationNumberStr = request.getParameter("reservationNumber");
            
            // VALIDACIÓN: Campo obligatorio
            if (!validator.esTextoValido(reservationNumberStr)) {
                Logger.warning("Intento de borrado sin número de reserva");
                out.println("<html><body style='font-family: Arial; padding: 20px;'>");
                out.println("<h2 style='color: #c33;'>❌ Error: El número de reserva es obligatorio</h2>");
                out.println("<a href='dashboard.jsp' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>← Volver al inicio</a>");
                out.println("</body></html>");
                return;
            }
            
            int reservationNumber = Integer.parseInt(reservationNumberStr);
            
            Logger.info("Intentando borrar reserva #" + reservationNumber);
            hotel.borrarReserva(reservationNumber);
            
            Logger.info("✓ Reserva borrada - #" + reservationNumber);
            Logger.logAccion("Sistema", "RESERVA_BORRADA", "Reserva #" + reservationNumber);
            
            out.println("<html><body style='font-family: Arial; padding: 20px;'>");
            out.println("<h2 style='color: green;'>✓ Reserva #" + reservationNumber + " cancelada exitosamente</h2>");
            out.println("<br><a href='dashboard.jsp' style='padding: 10px 20px; background: #4CAF50; color: white; text-decoration: none; border-radius: 5px;'>← Volver al inicio</a>");
            out.println("</body></html>");
            
        } catch (Exception e) {
            Logger.error("Error borrando reserva", e);
            out.println("<html><body style='font-family: Arial; padding: 20px;'>");
            out.println("<h2 style='color: #c33;'>❌ Error: " + e.getMessage() + "</h2>");
            out.println("<a href='dashboard.jsp' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>← Volver al inicio</a>");
            out.println("</body></html>");
        }
    }
}