package hotelmanagement.servlets;

import hotelmanagement.utils.Logger;
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/BloquearHabitacionServlet")
public class BloquearHabitacionServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String numeroHabitacionStr = request.getParameter("numeroHabitacion");
        String accion = request.getParameter("accion");
        String motivo = request.getParameter("motivo");
        
        if (numeroHabitacionStr == null || accion == null) {
            response.sendRedirect("BloqueoServlet");
            return;
        }
        
        int numeroHabitacion = Integer.parseInt(numeroHabitacionStr);
        
        // Obtener usuario de la sesión
        HttpSession session = request.getSession(false);
        String usuario = session != null ? (String) session.getAttribute("username") : "Sistema";
        
        Connection conn = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hoteldb", "root", "");
            
            if ("bloquear".equals(accion)) {
                bloquearHabitacion(conn, numeroHabitacion, motivo, usuario);
                Logger.info("✓ Habitación " + numeroHabitacion + " bloqueada por " + usuario);
                response.sendRedirect("BloqueoServlet?msg=bloqueada");
            } else if ("desbloquear".equals(accion)) {
                desbloquearHabitacion(conn, numeroHabitacion, usuario);
                Logger.info("✓ Habitación " + numeroHabitacion + " desbloqueada por " + usuario);
                response.sendRedirect("BloqueoServlet?msg=desbloqueada");
            }
            
        } catch (Exception e) {
            Logger.error("Error bloqueando/desbloqueando habitación", e);
            response.sendRedirect("BloqueoServlet");
        } finally {
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }
    
    private void bloquearHabitacion(Connection conn, int numeroHabitacion, String motivo, String usuario) 
            throws SQLException {
        // Actualizar estado de habitación
        PreparedStatement stmt = conn.prepareStatement(
            "UPDATE Habitacion SET estado = 'Mantenimiento' WHERE numeroHabitacion = ?");
        stmt.setInt(1, numeroHabitacion);
        stmt.executeUpdate();
        
        // Registrar en historial
        if (motivo == null || motivo.trim().isEmpty()) {
            motivo = "Mantenimiento general";
        }
        
        PreparedStatement stmtHistorial = conn.prepareStatement(
            "INSERT INTO HistorialBloqueo (numeroHabitacion, accion, motivo, usuario) VALUES (?, 'BLOQUEADA', ?, ?)");
        stmtHistorial.setInt(1, numeroHabitacion);
        stmtHistorial.setString(2, motivo);
        stmtHistorial.setString(3, usuario);
        stmtHistorial.executeUpdate();
    }
    
    private void desbloquearHabitacion(Connection conn, int numeroHabitacion, String usuario) 
            throws SQLException {
        // Actualizar estado de habitación
        PreparedStatement stmt = conn.prepareStatement(
            "UPDATE Habitacion SET estado = 'Disponible' WHERE numeroHabitacion = ?");
        stmt.setInt(1, numeroHabitacion);
        stmt.executeUpdate();
        
        // Registrar en historial
        PreparedStatement stmtHistorial = conn.prepareStatement(
            "INSERT INTO HistorialBloqueo (numeroHabitacion, accion, motivo, usuario) VALUES (?, 'DESBLOQUEADA', 'Mantenimiento finalizado', ?)");
        stmtHistorial.setInt(1, numeroHabitacion);
        stmtHistorial.setString(2, usuario);
        stmtHistorial.executeUpdate();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("BloqueoServlet");
    }
}