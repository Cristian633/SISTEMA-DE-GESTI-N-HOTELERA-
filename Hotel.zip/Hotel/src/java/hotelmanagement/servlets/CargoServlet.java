package hotelmanagement.servlets;

import hotelmanagement.utils.Logger;
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CargoServlet")
public class CargoServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String idStr = request.getParameter("numeroReserva");
        String descripcion = request.getParameter("descripcion");
        String montoStr = request.getParameter("monto");
        
        if (idStr == null || descripcion == null || montoStr == null) {
            response.sendRedirect("dashboard.jsp");
            return;
        }
        
        int numeroReserva = Integer.parseInt(idStr);
        double monto = Double.parseDouble(montoStr);
        
        Connection conn = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hoteldb", "root", "");
            
            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO Cargo (numeroReserva, descripcion, monto) VALUES (?, ?, ?)");
            stmt.setInt(1, numeroReserva);
            stmt.setString(2, descripcion);
            stmt.setDouble(3, monto);
            stmt.executeUpdate();
            
            Logger.info("✓ Cargo agregado - Reserva #" + numeroReserva + ": " + descripcion + " $" + monto);
            Logger.logAccion("Sistema", "CARGO_AGREGADO", "Reserva #" + numeroReserva + " - " + descripcion);
            
            response.sendRedirect("DetalleReservaServlet?id=" + numeroReserva + "&msg=cargo");
            
        } catch (Exception e) {
            Logger.error("Error agregando cargo", e);
            response.sendRedirect("dashboard.jsp");
        } finally {
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }
}