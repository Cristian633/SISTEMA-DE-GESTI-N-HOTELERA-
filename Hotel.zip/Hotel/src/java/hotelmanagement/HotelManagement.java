package hotelmanagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class HotelManagement {
    private Connection conn;

    public HotelManagement() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("✓ Driver cargado correctamente");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hoteldb", "root", "");
            if (conn == null) {
                throw new SQLException("Conexión a la base de datos falló");
            }
            System.out.println("✓ Conexión a BD establecida");
            inicializarHabitacionesSiVacio();
            mostrarEstado();
        } catch (ClassNotFoundException e) {
            System.err.println("✗ Error: Driver no encontrado - " + e.getMessage());
            throw new SQLException("Driver JDBC no encontrado: " + e.getMessage(), e);
        } catch (SQLException e) {
            System.err.println("✗ Error de conexión: " + e.getMessage());
            throw new SQLException("Error al conectar: " + e.getMessage(), e);
        }
    }

    private void inicializarHabitacionesSiVacio() throws SQLException {
        if (conn == null) {
            throw new SQLException("Conexión no disponible para inicialización");
        }
        PreparedStatement countStmt = conn.prepareStatement("SELECT COUNT(*) FROM Habitacion");
        ResultSet rs = countStmt.executeQuery();
        if (rs.next()) {
            if (rs.getInt(1) == 0) {
                conn.setAutoCommit(false);
                PreparedStatement insertStmt = conn.prepareStatement(
                    "INSERT INTO Habitacion (numeroHabitacion, estado, precio, tipo) VALUES (?, ?, ?, ?)");
                for (int i = 1; i <= 10; i++) {
                    insertStmt.setInt(1, i);
                    insertStmt.setString(2, "Disponible");
                    insertStmt.setDouble(3, 100.00 + (i * 10));
                    insertStmt.setString(4, i <= 3 ? "Estándar" : i <= 7 ? "Superior" : "Suite");
                    int rows = insertStmt.executeUpdate();
                    System.out.println("✓ Habitación " + i + " inicializada (" + rows + " filas afectadas): Disponible - $" + (100.00 + (i * 10)));
                }
                conn.commit();
                System.out.println("✓ 10 habitaciones iniciales creadas");
            } else {
                System.out.println("✓ Habitaciones ya inicializadas, verificando estado...");
                mostrarHabitaciones();
            }
        }
    }

    private void mostrarEstado() throws SQLException {
        if (conn == null) {
            throw new SQLException("Conexión no disponible para mostrar estado");
        }
        System.out.println("--- ESTADO ACTUAL ---");
        mostrarHabitaciones();
        mostrarReservas();
        System.out.println("--------------------");
    }

    private void mostrarHabitaciones() throws SQLException {
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Habitacion");
        ResultSet rs = stmt.executeQuery();
        System.out.println("Habitaciones:");
        while (rs.next()) {
            System.out.println("Hab " + rs.getInt("numeroHabitacion") + 
                ": " + (rs.getString("estado") != null ? rs.getString("estado").trim() : "nulo") + 
                " - $" + rs.getDouble("precio"));
        }
    }

    private void mostrarReservas() throws SQLException {
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Reserva");
        ResultSet rs = stmt.executeQuery();
        System.out.println("Reservas:");
        while (rs.next()) {
            System.out.println("Res # " + rs.getInt("numeroReserva") + 
                ": Hab " + rs.getInt("numeroHabitacion") + 
                " - " + rs.getString("nombreOcupante") + 
                " (" + rs.getDate("fechaEntrada") + " a " + rs.getDate("fechaSalida") + ")");
        }
    }

    public boolean verificarDisponibilidad(int numeroHabitacion) {
        if (conn == null) {
            System.err.println("✗ Conexión cerrada durante verificación");
            return false;
        }
        try {
            PreparedStatement stmt = conn.prepareStatement(
                "SELECT estado FROM Habitacion WHERE numeroHabitacion = ?");
            stmt.setInt(1, numeroHabitacion);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String estado = rs.getString("estado") != null ? rs.getString("estado").trim().toLowerCase() : "nulo";
                System.out.println("→ Verificando Hab " + numeroHabitacion + ": Estado en BD = '" + estado + "'");
                boolean disponible = "disponible".equals(estado);
                
                if ("mantenimiento".equals(estado)) {
                    System.out.println("→ Hab " + numeroHabitacion + " bloqueada para mantenimiento");
                } else if ("ocupada".equals(estado)) {
                    System.out.println("→ Hab " + numeroHabitacion + " ocupada");
                }
                
                System.out.println("→ Resultado verificación: " + (disponible ? "Disponible" : "No disponible"));
                return disponible;
            }
            System.out.println("✗ Hab " + numeroHabitacion + " no existe");
            return false;
        } catch (SQLException e) {
            System.err.println("✗ Error verificando disponibilidad: " + e.getMessage());
            return false;
        }
    }

    // MÉTODO ANTIGUO - Mantener para compatibilidad
    public void hacerReserva(int numeroHabitacion, String nombreOcupante, String fechaEntrada, String fechaSalida) {
        hacerReservaCompleta(numeroHabitacion, nombreOcupante, null, null, fechaEntrada, fechaSalida, 0.0);
    }

    // NUEVO MÉTODO COMPLETO CON TODOS LOS CAMPOS
    public void hacerReservaCompleta(int numeroHabitacion, String nombreOcupante, String telefono, 
                                      String email, String fechaEntrada, String fechaSalida, double precioTotal) {
        if (conn == null) {
            System.err.println("✗ Conexión cerrada durante reserva");
            return;
        }
        try {
            System.out.println("Intentando reserva completa para Hab " + numeroHabitacion);
            if (verificarDisponibilidad(numeroHabitacion)) {
                conn.setAutoCommit(false);
                
                PreparedStatement updateStmt = conn.prepareStatement(
                    "UPDATE Habitacion SET estado = 'Ocupada' WHERE numeroHabitacion = ?");
                updateStmt.setInt(1, numeroHabitacion);
                int updated = updateStmt.executeUpdate();
                System.out.println("→ Actualización a Ocupada: " + updated + " filas afectadas");

                PreparedStatement insertStmt = conn.prepareStatement(
                    "INSERT INTO Reserva (numeroHabitacion, nombreOcupante, telefono, email, fechaEntrada, fechaSalida, precioTotal, estadoReserva) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pendiente')",
                    PreparedStatement.RETURN_GENERATED_KEYS);
                insertStmt.setInt(1, numeroHabitacion);
                insertStmt.setString(2, nombreOcupante);
                insertStmt.setString(3, telefono);
                insertStmt.setString(4, email);
                insertStmt.setDate(5, java.sql.Date.valueOf(fechaEntrada));
                insertStmt.setDate(6, java.sql.Date.valueOf(fechaSalida));
                insertStmt.setDouble(7, precioTotal);
                insertStmt.executeUpdate();

                ResultSet rs = insertStmt.getGeneratedKeys();
                int numeroReserva = rs.next() ? rs.getInt(1) : -1;
                System.out.println("✓ Reserva creada: # " + numeroReserva + " para Hab " + numeroHabitacion + " - Precio: $" + precioTotal);

                conn.commit();
                mostrarEstado();
            } else {
                System.out.println("✗ Reserva fallida: Hab " + numeroHabitacion + " no disponible");
            }
        } catch (SQLException e) {
            System.err.println("✗ Error en reserva: " + e.getMessage());
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { System.err.println("✗ Error rollback: " + ex.getMessage()); }
        } finally {
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException e) { System.err.println("✗ Error reset auto-commit: " + e.getMessage()); }
        }
    }

    public void borrarReserva(int numeroReserva) {
        if (conn == null) {
            System.err.println("✗ Conexión cerrada durante borrado");
            return;
        }
        try {
            System.out.println("Intentando borrar Res # " + numeroReserva);
            PreparedStatement checkStmt = conn.prepareStatement(
                "SELECT numeroHabitacion FROM Reserva WHERE numeroReserva = ?");
            checkStmt.setInt(1, numeroReserva);
            ResultSet rs = checkStmt.executeQuery();
            
            if (rs.next()) {
                int numeroHabitacion = rs.getInt("numeroHabitacion");
                conn.setAutoCommit(false);

                PreparedStatement deleteStmt = conn.prepareStatement(
                    "DELETE FROM Reserva WHERE numeroReserva = ?");
                deleteStmt.setInt(1, numeroReserva);
                int deleted = deleteStmt.executeUpdate();
                System.out.println("→ Borrado de reserva: " + deleted + " filas afectadas");

                if (deleted > 0) {
                    PreparedStatement updateStmt = conn.prepareStatement(
                        "UPDATE Habitacion SET estado = 'Disponible' WHERE numeroHabitacion = ?");
                    updateStmt.setInt(1, numeroHabitacion);
                    int updated = updateStmt.executeUpdate();
                    System.out.println("→ Actualización a Disponible: " + updated + " filas afectadas");

                    PreparedStatement verifyStmt = conn.prepareStatement(
                        "SELECT estado FROM Habitacion WHERE numeroHabitacion = ?");
                    verifyStmt.setInt(1, numeroHabitacion);
                    ResultSet verifyRs = verifyStmt.executeQuery();
                    if (verifyRs.next()) {
                        String estado = verifyRs.getString("estado") != null ? verifyRs.getString("estado").trim().toLowerCase() : "nulo";
                        if ("disponible".equals(estado)) {
                            System.out.println("✓ Verificación: Hab " + numeroHabitacion + " ahora Disponible");
                        } else {
                            System.err.println("✗ Verificación fallida: Hab " + numeroHabitacion + " está " + estado);
                        }
                    }

                    conn.commit();
                    System.out.println("✓ Res # " + numeroReserva + " borrada - Hab " + numeroHabitacion + " liberada");
                } else {
                    conn.rollback();
                    System.out.println("✗ No se borró Res # " + numeroReserva + " - Posible error en DELETE");
                }
            } else {
                System.out.println("✗ Res # " + numeroReserva + " no encontrada en la BD");
            }
            mostrarEstado();
        } catch (SQLException e) {
            System.err.println("✗ Error borrando reserva: " + e.getMessage());
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { System.err.println("✗ Error rollback: " + ex.getMessage()); }
        } finally {
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException e) { System.err.println("✗ Error reset auto-commit: " + e.getMessage()); }
        }
    }

    public void cerrarConexion() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("✓ Conexión cerrada");
            }
        } catch (SQLException e) {
            System.err.println("✗ Error cerrando conexión: " + e.getMessage());
        }
    }
}