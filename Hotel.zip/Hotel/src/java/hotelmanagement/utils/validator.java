/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotelmanagement.utils;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;
/**
 *
 * @author deleo
 */
public class validator {
    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
    
    private static final Pattern PHONE_PATTERN = 
        Pattern.compile("^[0-9]{8,15}$");
    
    /**
     * Valida que una cadena no esté vacía
     */
    public static boolean esTextoValido(String texto) {
        return texto != null && !texto.trim().isEmpty();
    }
    
    /**
     * Valida formato de email
     */
    public static boolean esEmailValido(String email) {
        if (!esTextoValido(email)) return false;
        return EMAIL_PATTERN.matcher(email).matches();
    }
    
    /**
     * Valida formato de teléfono
     */
    public static boolean esTelefonoValido(String telefono) {
        if (!esTextoValido(telefono)) return false;
        return PHONE_PATTERN.matcher(telefono.replaceAll("[\\s-]", "")).matches();
    }
    
    /**
     * Valida que el número de habitación sea válido
     */
    public static boolean esNumeroHabitacionValido(int numeroHabitacion) {
        return numeroHabitacion > 0 && numeroHabitacion <= 100; // Ajustar según tu hotel
    }
    
    /**
     * Valida que las fechas sean correctas
     * Retorna null si todo está bien, o un mensaje de error si algo falla
     */
    public static String validarFechas(Date fechaEntrada, Date fechaSalida) {
        Date hoy = new Date();
        
        if (fechaEntrada == null || fechaSalida == null) {
            return "Las fechas no pueden estar vacías";
        }
        
        // Normalizar hoy para comparar solo fechas (sin hora)
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date hoyNormalizado = sdf.parse(sdf.format(hoy));
            Date entradaNormalizada = sdf.parse(sdf.format(fechaEntrada));
            
            if (entradaNormalizada.before(hoyNormalizado)) {
                return "La fecha de entrada no puede ser anterior a hoy";
            }
        } catch (Exception e) {
            return "Error al validar fechas";
        }
        
        if (fechaSalida.before(fechaEntrada) || fechaSalida.equals(fechaEntrada)) {
            return "La fecha de salida debe ser posterior a la fecha de entrada";
        }
        
        // Validar que la estancia no sea mayor a 30 días
        long dias = (fechaSalida.getTime() - fechaEntrada.getTime()) / (1000 * 60 * 60 * 24);
        if (dias > 30) {
            return "La estancia no puede ser mayor a 30 días";
        }
        
        return null; // Sin errores
    }
    
    /**
     * Valida nombre del ocupante
     * Retorna null si todo está bien, o un mensaje de error si algo falla
     */
    public static String validarNombreOcupante(String nombre) {
        if (!esTextoValido(nombre)) {
            return "El nombre no puede estar vacío";
        }
        
        if (nombre.length() < 3) {
            return "El nombre debe tener al menos 3 caracteres";
        }
        
        if (nombre.length() > 100) {
            return "El nombre es demasiado largo";
        }
        
        if (!nombre.matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$")) {
            return "El nombre solo puede contener letras y espacios";
        }
        
        return null; // Sin errores
    }
    
    /**
     * Sanitiza entrada de texto para prevenir problemas
     */
    public static String sanitizarTexto(String texto) {
        if (texto == null) return "";
        return texto.trim()
                   .replaceAll("[<>\"']", "")
                   .replaceAll("\\s+", " ");
    }
    
    /**
     * Formatea una fecha a String legible
     */
    public static String formatearFecha(Date fecha) {
        if (fecha == null) return "";
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(fecha);
    }
}
