/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotelmanagement.utils;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 *
 * @author deleo
 */
public class Logger {
    private static final String LOG_FILE = "hotel_system.log";
    private static final SimpleDateFormat DATE_FORMAT = 
        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    public enum Level {
        INFO, WARNING, ERROR, DEBUG
    }
    
    /**
     * Registra un mensaje en el log
     */
    public static void log(Level level, String message) {
        log(level, message, null);
    }
    
    /**
     * Registra un mensaje con excepción en el log
     */
    public static void log(Level level, String message, Throwable throwable) {
        String timestamp = DATE_FORMAT.format(new Date());
        String logMessage = String.format("[%s] [%s] %s", timestamp, level, message);
        
        // Imprimir en consola
        if (level == Level.ERROR) {
            System.err.println(logMessage);
        } else {
            System.out.println(logMessage);
        }
        
        // Escribir en archivo
        try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_FILE, true))) {
            writer.println(logMessage);
            if (throwable != null) {
                throwable.printStackTrace(writer);
            }
        } catch (IOException e) {
            System.err.println("Error escribiendo log: " + e.getMessage());
        }
    }
    
    // Métodos de conveniencia
    public static void info(String message) {
        log(Level.INFO, message);
    }
    
    public static void warning(String message) {
        log(Level.WARNING, message);
    }
    
    public static void error(String message) {
        log(Level.ERROR, message);
    }
    
    public static void error(String message, Throwable throwable) {
        log(Level.ERROR, message, throwable);
    }
    
    public static void debug(String message) {
        log(Level.DEBUG, message);
    }
    
    /**
     * Registra una acción de usuario
     */
    public static void logAccion(String usuario, String accion, String detalle) {
        String message = String.format("Usuario: %s | Acción: %s | Detalle: %s", 
                                      usuario, accion, detalle);
        info(message);
    }
}
