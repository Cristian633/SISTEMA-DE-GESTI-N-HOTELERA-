package hotelmanagement.models;

/**
 * Clase modelo para Habitacion
 * P
 */
public class Habitacion {
    private int numeroHabitacion;
    private String tipo; // "Simple", "Doble", "Suite"
    private String estado; // "Disponible", "Ocupada", "Mantenimiento"
    private double precio;
    private int capacidad;
    private String descripcion;

    // Constructor vacío
    public Habitacion() {}

    // Constructor con datos básicos
    public Habitacion(int numeroHabitacion, String tipo, double precio) {
        this.numeroHabitacion = numeroHabitacion;
        this.tipo = tipo;
        this.precio = precio;
        this.estado = "Disponible";
    }

    // Getters y Setters
    public int getNumeroHabitacion() { 
        return numeroHabitacion; 
    }
    
    public void setNumeroHabitacion(int numeroHabitacion) { 
        this.numeroHabitacion = numeroHabitacion; 
    }

    public String getTipo() { 
        return tipo; 
    }
    
    public void setTipo(String tipo) { 
        this.tipo = tipo; 
    }

    public String getEstado() { 
        return estado; 
    }
    
    public void setEstado(String estado) { 
        this.estado = estado; 
    }

    public double getPrecio() { 
        return precio; 
    }
    
    public void setPrecio(double precio) { 
        this.precio = precio; 
    }

    public int getCapacidad() { 
        return capacidad; 
    }
    
    public void setCapacidad(int capacidad) { 
        this.capacidad = capacidad; 
    }

    public String getDescripcion() { 
        return descripcion; 
    }
    
    public void setDescripcion(String descripcion) { 
        this.descripcion = descripcion; 
    }

    // Método útil: verifica si está disponible
    public boolean estaDisponible() {
        return "Disponible".equalsIgnoreCase(estado);
    }

    @Override
    public String toString() {
        return "Habitación " + numeroHabitacion + " (" + tipo + ") - " + estado;
    }
}