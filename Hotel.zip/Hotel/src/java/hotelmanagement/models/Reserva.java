package hotelmanagement.models;

import java.util.Date;

/**
 * Clase modelo para Reserva
 * PASO 1: Crear esta clase básica
 */
public class Reserva {
    private int numeroReserva;
    private int numeroHabitacion;
    private String nombreOcupante;
    private String telefono;
    private String email;
    private Date fechaEntrada;
    private Date fechaSalida;
    private double precioTotal;
    private String estado; // "Activa", "Cancelada", "Completada"

    // Constructor vacío
    public Reserva() {}

    // Constructor con datos básicos
    public Reserva(int numeroHabitacion, String nombreOcupante, Date fechaEntrada, Date fechaSalida) {
        this.numeroHabitacion = numeroHabitacion;
        this.nombreOcupante = nombreOcupante;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        this.estado = "Activa";
    }

    // Getters y Setters
    public int getNumeroReserva() { 
        return numeroReserva; 
    }
    
    public void setNumeroReserva(int numeroReserva) { 
        this.numeroReserva = numeroReserva; 
    }

    public int getNumeroHabitacion() { 
        return numeroHabitacion; 
    }
    
    public void setNumeroHabitacion(int numeroHabitacion) { 
        this.numeroHabitacion = numeroHabitacion; 
    }

    public String getNombreOcupante() { 
        return nombreOcupante; 
    }
    
    public void setNombreOcupante(String nombreOcupante) { 
        this.nombreOcupante = nombreOcupante; 
    }

    public String getTelefono() { 
        return telefono; 
    }
    
    public void setTelefono(String telefono) { 
        this.telefono = telefono; 
    }

    public String getEmail() { 
        return email; 
    }
    
    public void setEmail(String email) { 
        this.email = email; 
    }

    public Date getFechaEntrada() { 
        return fechaEntrada; 
    }
    
    public void setFechaEntrada(Date fechaEntrada) { 
        this.fechaEntrada = fechaEntrada; 
    }

    public Date getFechaSalida() { 
        return fechaSalida; 
    }
    
    public void setFechaSalida(Date fechaSalida) { 
        this.fechaSalida = fechaSalida; 
    }

    public double getPrecioTotal() { 
        return precioTotal; 
    }
    
    public void setPrecioTotal(double precioTotal) { 
        this.precioTotal = precioTotal; 
    }

    public String getEstado() { 
        return estado; 
    }
    
    public void setEstado(String estado) { 
        this.estado = estado; 
    }

    // Método útil: calcula días de estancia
    public long getDiasEstancia() {
        if (fechaEntrada != null && fechaSalida != null) {
            return (fechaSalida.getTime() - fechaEntrada.getTime()) / (1000 * 60 * 60 * 24);
        }
        return 0;
    }

    @Override
    public String toString() {
        return "Reserva #" + numeroReserva + " - " + nombreOcupante + 
               " (Hab " + numeroHabitacion + ")";
    }
}