/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotelmanagement.exceptions;

/**
 *
 * @author deleo
 */
public class HotelException extends Exception {
    public HotelException(String message) {
        super(message);
}
public HotelException(String message, Throwable cause) {
        super(message, cause);
    }
}
/** 
 * Excepción cuando una habitación no está disponible
 */
class HabitacionNoDisponibleException extends HotelException {
    private int numeroHabitacion;
    
    public HabitacionNoDisponibleException(int numeroHabitacion) {
        super("La habitación " + numeroHabitacion + " no está disponible");
        this.numeroHabitacion = numeroHabitacion;
    }
    
    public int getNumeroHabitacion() {
        return numeroHabitacion;
    }
}
/**
 * Excepción cuando hay conflicto de fechas
 */
class ConflictoFechasException extends HotelException {
    public ConflictoFechasException(String message) {
        super(message);
    }
}

/**
 * Excepción cuando una reserva no existe
 */
class ReservaNoEncontradaException extends HotelException {
    private int numeroReserva;
    
    public ReservaNoEncontradaException(int numeroReserva) {
        super("La reserva #" + numeroReserva + " no fue encontrada");
        this.numeroReserva = numeroReserva;
    }
    
    public int getNumeroReserva() {
        return numeroReserva;
    }
}

/**
 * Excepción para validación de datos
 */
class ValidacionException extends HotelException {
    private String campo;
    
    public ValidacionException(String campo, String message) {
        super(message);
        this.campo = campo;
    }
    
    public String getCampo() {
        return campo;
    }
}
